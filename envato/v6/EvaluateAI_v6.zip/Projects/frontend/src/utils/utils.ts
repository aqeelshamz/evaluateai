const serverURL = "http://localhost:8080"
const hostname = "https://evaluateai.vercel.app";
const currencySymbol = "₹";
const appName = "EvaluateAI";
//UploadThing
const maxFileCount = 10;
const maxFileSize = "8MB"; // 8MB

export { serverURL, currencySymbol, appName, maxFileCount, maxFileSize, hostname };