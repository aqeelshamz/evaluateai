const serverURL = "http://localhost:8080"
const currencySymbol = "₹";
const appName = "EvaluateAI";
//UploadThing
const maxFileCount = 10;
const maxFileSize = "8MB"; // 8MB

export { serverURL, currencySymbol, appName, maxFileCount, maxFileSize };