import 'dart:ui';

Color primaryColor = Color(0xFF9A4CFF);
