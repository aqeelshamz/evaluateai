import React from "react";

export default function Loading() {
    return <p>Loading...</p>
}