import 'package:flutter/material.dart';

const Color primaryColor = Color(0xFF9A4CFF);
const Color secondaryColor = Color(0xFFF43098);
