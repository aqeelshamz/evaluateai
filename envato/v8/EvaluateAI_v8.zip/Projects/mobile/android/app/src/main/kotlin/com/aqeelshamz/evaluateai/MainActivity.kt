package com.aqeelshamz.evaluateai

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
