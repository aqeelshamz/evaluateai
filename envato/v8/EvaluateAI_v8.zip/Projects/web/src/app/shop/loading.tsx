"use client";

export default function Page() {
  return (
    <div className="flex">
      <span className="mr-2 loading loading-spinner text-primary"></span> Loading...
    </div>
  );
}
